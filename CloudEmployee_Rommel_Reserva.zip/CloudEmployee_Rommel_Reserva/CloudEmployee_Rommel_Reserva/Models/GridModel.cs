﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CloudEmployee_Rommel_Reserva.Models
{
    public class Employee
    {
        public string EmployeeCode { get; set; }
        public string EmployeeName { get; set; }
        public string EmployeeAddress { get; set; }
        public int EmployeeSalary { get; set; }
    }
}
